--liquibase formatted sql
/* https://www.liquibase.org/documentation/sql_format.html */

--changeset authorname:1
/* Insert SQL change objects here */


--changeset authorname:2
/* Insert SQL change objects here */



